# Haushaltsbuch App

![Haushaltsbuch Logo](/assets/logo.png)

Willkommen in der Haushaltsbuch-App! Diese Anwendung ermöglicht es Ihnen, Ihre Einnahmen und Ausgaben einfach und effizient zu verfolgen.

## Funktionen

- **Hinzufügen von Transaktionen**: Fügen Sie Ihre Transaktionen einfach hinzu, indem Sie den Betrag, die Kategorie, den Zyklus und das Datum angeben.

- **Dashboard-Ansicht**: Sehen Sie sich ein klares Dashboard an, das Ihnen einen Überblick über Ihr Budget bietet. Sie können finanzielle Ziele setzen und überwachen.

- **Transaktionen filtern**: Filtern Sie Ihre Transaktionen nach Kategorie, Zyklus und Monat für eine genauere Verwaltung.

- **Bearbeiten und Löschen von Transaktionen**: Bearbeiten oder löschen Sie vorhandene Transaktionen mit Leichtigkeit.

## Wie man die App benutzt

1. **Startseite**: Die Startseite begrüßt Sie mit Informationen zur Anwendung und ihren Funktionen.

2. **Neue Transaktion**: Fügen Sie neue Transaktionen hinzu, indem Sie die Option "Neue Transaktion" in der Navigationsleiste auswählen. Füllen Sie das Formular mit den entsprechenden Details aus.

3. **Dashboard**: Sehen Sie sich Ihr Dashboard an, indem Sie die Option "Dashboard" in der Navigationsleiste auswählen. Verwenden Sie die Filter, um die Ansicht anzupassen.

4. **Anzeigen von Transaktionen**: Sehen Sie sich das Transaktionsprotokoll an, indem Sie "Transaktionshistorie" in der Navigationsleiste auswählen.

5. **Bearbeiten und Löschen**: Bearbeiten oder löschen Sie eine Transaktion mithilfe der entsprechenden Schaltflächen.

## Verwendete Technologien

- HTML5
- CSS3
- JavaScript (ES6)
## Vorschau

![Haushaltsbuch Vorschau](/assets/image-gif.gif)

## Wie man beitragen kann

1. Klone dieses Repository.
2. Bringe Verbesserungen oder Korrekturen ein.
3. Stelle eine Pull-Anfrage.

Wir freuen uns auf deine Beiträge, um diese App noch besser zu machen!

&copy; 2023 Haushaltsbuch App | [Impressum](views/impressum.html)
