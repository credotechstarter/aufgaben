// dashboard.js

// Warten, bis das DOM vollständig geladen ist
document.addEventListener('DOMContentLoaded', function () {
    // Referenzen zu den DOM-Elementen holen
    const dashboardTransactionList = document.getElementById('dashboardTransactionList');
    const filterCategoryInput = document.getElementById('filterCategory');
    const filterCycleInput = document.getElementById('filterCycle');
    const filterMonthInput = document.getElementById('filterMonth');

    // Transaktionen aus dem Local Storage laden oder leeres Array verwenden
    const savedTransactions = JSON.parse(localStorage.getItem('transactions')) || [];

    // Alle Transaktionen im Dashboard-Historienbereich anzeigen
    displayAllTransactions();

    // Funktion zum Hinzufügen einer Transaktion zum Dashboard-Historienbereich
    function addTransactionToDashboardList(transactionText, index) {
        const transactionItem = document.createElement('li');
        transactionItem.innerHTML = transactionText;
        dashboardTransactionList.appendChild(transactionItem);
    }

    // Funktion zum Anzeigen aller Transaktionen
    function displayAllTransactions() {
        dashboardTransactionList.innerHTML = '';
        savedTransactions.forEach((transaction, index) => {
            addTransactionToDashboardList(transaction, index);
        });
    }

    // Event-Listener für Kategorie-Filteränderungen
    filterCategoryInput.addEventListener('change', function () {
        const selectedCategory = filterCategoryInput.value;
        filterTransactionsByCategory(selectedCategory);
    });

    // Event-Listener für Zyklus-Filteränderungen
    filterCycleInput.addEventListener('change', function () {
        const selectedCycle = filterCycleInput.value;
        filterTransactionsByCycle(selectedCycle);
    });

    // Funktion zum Filtern von Transaktionen nach Kategorie
    function filterTransactionsByCategory(category) {
        const filteredTransactions = savedTransactions.filter(transaction => {
            return getCategoryFromTransaction(transaction) === category;
        });

        updateDashboardList(filteredTransactions);
    }

    // Funktion zum Filtern von Transaktionen nach Zyklus
    function filterTransactionsByCycle(cycle) {
        const filteredTransactions = savedTransactions.filter(transaction => {
            return getCycleFromTransaction(transaction) === cycle;
        });

        updateDashboardList(filteredTransactions);
    }

    // Funktion zum Aktualisieren der Dashboard-Liste basierend auf gefilterten Transaktionen
    function updateDashboardList(transactions) {
        dashboardTransactionList.innerHTML = '';
        transactions.forEach((transaction, index) => {
            addTransactionToDashboardList(transaction, index);
        });
    }

    // Funktion zum Extrahieren der Kategorie aus der Transaktion
    function getCategoryFromTransaction(transactionText) {
        return transactionText.match(/Kategorie: (\w+)/)[1];
    }

    // Funktion zum Extrahieren des Zyklus aus der Transaktion
    function getCycleFromTransaction(transactionText) {
        return transactionText.match(/Zyklus: (\w+)/)[1];
    }
});
