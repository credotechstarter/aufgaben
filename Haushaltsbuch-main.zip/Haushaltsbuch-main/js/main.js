import { initializeDashboard } from './dashboard/dashboard.js';
import { initializeTransaction } from './transaction/transactions.js';

document.addEventListener('DOMContentLoaded', function () {
    const currentPage = window.location.pathname;
    console.log('Main script loaded...');

    if (currentPage.includes('dashboard.html')) {
        initializeDashboard();
    } else if (currentPage.includes('transaction.html')) {
        initializeTransaction();
    }
});
