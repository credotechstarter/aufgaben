document.addEventListener('DOMContentLoaded', function () {
    const transactionForm = document.getElementById('transactionForm');
    const transactionList = document.getElementById('transactionList');
    let oldTransactionIndex;

    // Charger les transactions depuis le Local Storage
    const savedTransactions = JSON.parse(localStorage.getItem('transactions')) || [];

    // Afficher les transactions existantes
    savedTransactions.forEach((transaction, index) => {
        addTransactionToList(transaction, index);
    });

    transactionForm.addEventListener('submit', function (event) {
        event.preventDefault();

        // Obtenir les valeurs du formulaire
        const amount = document.getElementById('amount').value;
        const category = document.getElementById('category').value;
        const cycle = document.getElementById('cycle').value;
        const transactionDate = document.getElementById('transactionDate').value;

        // Formatage de la transaction
        const formattedTransaction = `Betrag: ${amount}, Kategorie: ${category}, Zyklus: ${cycle}, Datum: ${transactionDate}`;

        if (oldTransactionIndex !== undefined) {
            // Si oldTransactionIndex est défini, cela signifie qu'il s'agit d'une modification
            // Mettre à jour la transaction existante avec le nouveau montant
            savedTransactions[oldTransactionIndex] = `<span class="transaction ${getCategoryType(category)}">${formattedTransaction}</span>`;
        } else {
            // Sinon, c'est une nouvelle transaction, l'ajouter à la liste
            savedTransactions.push(`<span class="transaction ${getCategoryType(category)}">${formattedTransaction}</span>`);
        }

        // Ajouter la transaction à la liste
        addTransactionToList(savedTransactions[savedTransactions.length - 1], savedTransactions.length - 1);

        // Ajouter la transaction au Local Storage
        localStorage.setItem('transactions', JSON.stringify(savedTransactions));

        // Réinitialiser les champs du formulaire et oldTransactionIndex
        transactionForm.reset();
        oldTransactionIndex = undefined;
    });

    function addTransactionToList(transactionText, index) {
        const transactionItem = document.createElement('li');
        const editButton = document.createElement('button');
        const deleteButton = document.createElement('button');

        editButton.textContent = 'Bearbeiten';
        editButton.addEventListener('click', function() {
            editTransactionHandler(transactionText, index);
        });

        deleteButton.textContent = 'Löschen';
        deleteButton.addEventListener('click', function() {
            deleteTransactionHandler(index);
        });

        transactionItem.innerHTML = `${transactionText} `;
        transactionItem.appendChild(editButton);
        transactionItem.appendChild(deleteButton);
        transactionList.appendChild(transactionItem);
    }

    // Fonction pour éditer une transaction
    function editTransactionHandler(transactionText, index) {
        oldTransactionIndex = index;

        // Extraire le montant actuel de la transaction
        const currentAmount = transactionText.match(/Betrag: (\d+)/)[1];

        // Pré-remplir le formulaire avec les valeurs actuelles
        document.getElementById('amount').value = currentAmount;
        document.getElementById('category').value = getCategoryFromTransaction(transactionText);
        document.getElementById('cycle').value = getCycleFromTransaction(transactionText);
        document.getElementById('transactionDate').value = getDateFromTransaction(transactionText);

        // Ouvrir le modal
        openModal();
    }

    // Fonction pour supprimer une transaction
    function deleteTransactionHandler(index) {
        // Supprimer la transaction du tableau savedTransactions
        savedTransactions.splice(index, 1);

        // Mettre à jour le Local Storage
        localStorage.setItem('transactions', JSON.stringify(savedTransactions));

        // Mettre à jour l'affichage
        updateTransactionList();
    }

    // Fonction pour mettre à jour l'affichage de la liste de transactions
    function updateTransactionList() {
        // Vider la liste existante
        transactionList.innerHTML = '';

        // Afficher les transactions existantes
        savedTransactions.forEach((transaction, index) => {
            addTransactionToList(transaction, index);
        });
    }

    // Fonction pour ouvrir le modal
    function openModal() {
        const modal = document.getElementById('editModal');
        modal.style.display = 'block';
    }

    // Fonction pour fermer le modal
    function closeModal() {
        const modal = document.getElementById('editModal');
        modal.style.display = 'none';
    }

    // Fonction appelée lorsque "Speichern" est cliqué dans le modal
    function saveEditedTransaction() {
        // Fermer le modal
        closeModal();
    }

    // Fonction pour extraire la catégorie de la transaction
    function getCategoryFromTransaction(transactionText) {
        return transactionText.match(/Kategorie: (\w+)/)[1];
    }

    // Fonction pour extraire le cycle de la transaction
    function getCycleFromTransaction(transactionText) {
        return transactionText.match(/Zyklus: (\w+)/)[1];
    }

    function getDateFromTransaction(transactionText) {
        const dateMatch = transactionText.match(/Datum: (\d{4}-\d{2}-\d{2})/);
            if (dateMatch) {
         const dateParts = dateMatch[1].split('-');
            return `${dateParts[0]}.${dateParts[1]}.${dateParts[2]}`;
        }
    return '';
}

    // Fonction pour déterminer le type de catégorie (Einkommen ou Ausgaben)
    function getCategoryType(category) {
        if (category.toLowerCase() === 'einkommen') {
            return 'income';
        } else if (category.toLowerCase() === 'ausgaben') {
            return 'expense';
        }
        // Par défaut, renvoyer 'transaction' si la catégorie n'est ni Einkommen ni Ausgaben
        return 'transaction';
    }

});
